/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package InvoiceGenerator;

/**
 *
 * @author Rahul Bhat
 */
public interface InvoiceOperations {
    public void addToInvoice(String name,int quantity);
    public void deleteFromInvoice(String name);
    public void updateInvoice(String name, int new_quantity);
}
