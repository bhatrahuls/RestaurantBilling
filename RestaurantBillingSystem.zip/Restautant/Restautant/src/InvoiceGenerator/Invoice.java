/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InvoiceGenerator;

import MenuManager.Menu;
import OrderManager.Order;
import java.util.ArrayList;

/**
 *
 * @author Rahul Bhat
 */
public class Invoice implements InvoiceOperations{
    public Menu menu;
    public int invoiceId;
    public PaymentMode mode;
    public Order order;
    public String name;
    public float price;
    public int quantity;
    public static float itemTotal=0;
    public ArrayList<InvoiceItem> purchaseList;
    public Invoice(){
        purchaseList = new ArrayList<InvoiceItem>();
    }

    @Override
    public void addToInvoice(String name, int quantity) {
        itemTotal=getItemTotal(price,quantity);
        price=getPrice(name);
        InvoiceItem item=new InvoiceItem(name,price,quantity,itemTotal);
        purchaseList.add(item);
        itemTotal+=itemTotal;
    }

    @Override
    public void deleteFromInvoice(String name) {
        for(int i=0; i<purchaseList.size();i++){
            if(purchaseList.get(i).name.equalsIgnoreCase(name)){
                purchaseList.remove(i);  
                break;
            }
        }
    }

    @Override
    public void updateInvoice(String name, int new_quantity) {
        for(int i=0; i<purchaseList.size();i++){
            if(purchaseList.get(i).name.equalsIgnoreCase(name)){
                itemTotal=getItemTotal(price,new_quantity);
                purchaseList.get(i).quantity=new_quantity;
                purchaseList.get(i).itemTotal=itemTotal;
                break;
            
            }
        }
    }
    
    public enum PaymentMode{
    UPI, CASH, DEBIT, CREDIT
    }
    
    public float getPrice(String name){
        for(int j=0;j<menu.listItem.size();j++){
            if(menu.listItem.get(j).name.equalsIgnoreCase(name)){
                price=menu.listItem.get(j).price;
                break;
            }
        }
        return price;

    }
    
    public float getItemTotal(float price, int quantity){
        return price*quantity;
    }
    
}
