/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InvoiceGenerator;

/**
 *
 * @author Rahul Bhat
 */
public class InvoiceItem {
    public String name;
    public int quantity;
    public float price;
    public float itemTotal;

    public InvoiceItem(String name, float price, int quantity, float itemTotal) {
        this.name = name;
        this.quantity = quantity;
        this.price=price;
        this.itemTotal = itemTotal;
    }
    
}
