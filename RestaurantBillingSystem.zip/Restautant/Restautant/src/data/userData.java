/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import javax.swing.JOptionPane;
import model.User;
import java.sql.*;
/**
 *
 * @author Rahul Bhat
 */
public class userData {
    public static void save(User user){
        String query="insert into user(name,email,phone,password,status) values('"+user.getName()+"','"+user.getEmail()+"','"+user.getPhone()+"','"+user.getPassword()+"','true')";
        DbOperations.setDataorDelete(query, "Registered Successfully! Wait for Admin Approval!");
        
    }
    
    public static User login(String email, String password){
        User user=null;    
        try{
            ResultSet rs= DbOperations.getData("select * from user where email='"+email+"' and password='"+password+"'");
            while(rs.next()){
                user =new User();
                user.setStatus(rs.getString("status"));
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return user;
    }
    
    
}
