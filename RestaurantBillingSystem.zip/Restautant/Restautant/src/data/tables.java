/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import javax.swing.JOptionPane;

/**
 *
 * @author Rahul Bhat
 */
public class tables {
    public static void main(String[] args){
        try{
            //String userTable="create table user(id int AUTO_INCREMENT primary key, name varchar(30), email varchar(50), phone varchar(10), password varchar(20), status varchar(20), UNIQUE (email))";
            //String add="insert into user (name,email,phone,password) values ('user','user@gmail.com','1234567890','user')";
            //String add="update user set status='true' where name='user'";
            //DbOperations.setDataorDelete(userTable,"User Table Created Successfully");
            //DbOperations.setDataorDelete(add,"User Table Created Successfully");
            String productTable="create table menu (id int AUTO_INCREMENT primary key, name varchar(30),price float)";
            DbOperations.setDataorDelete(productTable,"User Table Created Successfully");
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
