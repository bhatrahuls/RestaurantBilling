/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Rahul Bhat
 */

public class ConnectionProvider {
    
    public static Connection getCon(){
    try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant","root","");
            return con;
    }catch(Exception e){
        return null;
    }
}
    /*private static ConnectionProvider dbc;
    private static Connection con;
    private ConnectionProvider(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant","root","");
        }
        catch(Exception e){
        }
    }
    public static void createdbc(){
        if(dbc==null) dbc= new ConnectionProvider();
    }
    public static Connection connection(){
        return ConnectionProvider.con;
    }*/
    
}
