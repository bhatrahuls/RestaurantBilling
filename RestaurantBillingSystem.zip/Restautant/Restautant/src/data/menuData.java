/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import MenuManager.Menu;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/**
 *
 * @author Rahul Bhat
 */
public class menuData {
    public static String query;
    public static void save(){
        Menu menu=Menu.getSingleInstance();
        
        for(int i=0;i<menu.listItem.size();i++){
            query="insert into menu(name, price) values('"+menu.listItem.get(i).name+"','"+menu.listItem.get(i).price+"')";
            DbOperations.setDataorDelete(query,"Successfully Inserted!"); 
        }
        
    }
    public static void delete(String name){
        query="delete from menu where name='"+name+"'";
        DbOperations.setDataorDelete(query,"Successfully Deleted!"); 
        
        
    }
    
    public static void update(String name,float price){
        query="update menu set price='"+price+"' where name= '"+name+"'";
        DbOperations.setDataorDelete(query,"Successfully Updated!"); 
        
        
    }
    
    public static void Serialize(String path,Menu menu) throws IOException{
        FileOutputStream fout;
        ObjectOutputStream out;
        fout = new FileOutputStream(path);
        out = new ObjectOutputStream(fout);
        out.writeObject(menu);
        out.flush();
        fout.close();
        
    }
    
    public static Menu Deserialize(String path) throws IOException, ClassNotFoundException{
        FileInputStream fin;
        ObjectInputStream in;
        Menu menu;
        fin = new FileInputStream(path);
        in = new ObjectInputStream(fin);
        menu = (Menu)in.readObject();
        in.close();
        fin.close();
        return menu;
    }
    
    
}
