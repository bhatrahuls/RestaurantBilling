/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package OrderManager;

/**
 *
 * @author Rahul Bhat
 */
public interface OrderOperations {
    void addItem(String name,int quantity);
    void deleteItem(String name);
    void updateQuantity(String name,int newQuantity);
}
