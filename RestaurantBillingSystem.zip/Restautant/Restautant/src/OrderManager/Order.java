/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OrderManager;

import MenuManager.Menu;
import java.util.ArrayList;

/**
 *
 * @author Rahul Bhat
 */
public class Order implements OrderOperations{
    //public Menu menu;
    //public static int tableNo;
    //public static int orderId;
    public ArrayList<OrderItem> orderList;
    private Order(){
        //this.menu=menu;
        orderList = new ArrayList<OrderItem>();
    }
    public static Order order=new Order();
    
    @Override
    public void addItem(String name, int quantity) {
        OrderItem item = new OrderItem(name,quantity);
        
        orderList.add(item);
    }

    @Override
    public void deleteItem(String name) {
        for(int i=0; i<orderList.size(); i++){
            if(orderList.get(i).name.equalsIgnoreCase(name)){
                orderList.remove(i);
            }
        }
    }

    @Override
    public void updateQuantity(String name, int newQuantity) {
        for(int i=0; i<orderList.size(); i++){
            if(orderList.get(i).name.equalsIgnoreCase(name)){
                orderList.get(i).quantity= newQuantity;
            }
        }
    }
    
    public static Order getSingleInstance(){
        return order;
    }
}
    
    
    

