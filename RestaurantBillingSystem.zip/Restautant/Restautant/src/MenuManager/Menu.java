/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MenuManager;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Rahul Bhat
 */
public class Menu implements MenuOperations, Serializable{
    public ArrayList<Item> listItem;
    private Menu(){
        listItem = new ArrayList<>();
    }
    public static Menu menu=new Menu();
    @Override
    public void addItem(String name, float price) {
        Item item=new Item(name, price);
        
        listItem.add(item);
    }

    @Override
    public void deleteItem(String name) {
        for(int i=0; i<listItem.size(); i++){
            if(listItem.get(i).name.equalsIgnoreCase(name)){
                listItem.remove(i);
                break;
            }
        }
    }

    @Override
    public void updatePrice(String name, float price) {
        for(int i=0; i<listItem.size(); i++){
            if(listItem.get(i).name.equalsIgnoreCase(name)){
                listItem.get(i).price=price;
                break;
            }
        }
    }
    
    public static Menu getSingleInstance(){
        return menu;
    }
}
