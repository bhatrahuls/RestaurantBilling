/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package MenuManager;

/**
 *
 * @author Rahul Bhat
 */
public interface MenuOperations {
    void addItem(String name, float price);
    void deleteItem(String name);
    void updatePrice(String name, float price);
}
