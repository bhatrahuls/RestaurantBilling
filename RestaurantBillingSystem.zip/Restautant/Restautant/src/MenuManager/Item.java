/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MenuManager;

import java.io.Serializable;

/**
 *
 * @author Rahul Bhat
 */
public class Item implements Serializable{
    public String name;
    public float price;

    public Item(String name, float price) {
        this.name = name;
        this.price = price;
    }
    
    
}
